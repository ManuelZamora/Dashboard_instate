<?php

namespace App\Http\Controllers;

use App\modelos\usuarios;
use Illuminate\Support\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;
use App\modelos\ArchivosM;
use App\modelos\TiposArchivosM;
use App\modelos\CasasIntersM;
use App\modelos\proyectos;
use Illuminate\Support\Carbon;
use App\Http\Controllers\pdfcontroller; 
use App\modelos\diagnostico;
use App\modelos\proyectoactive;
 

class routerwebController extends Controller
{
    //
    function actproyecto(){
        $proyecto=proyectoactive::where('status','=','pendiente')->get();
        $usuarios = session::get('informacion');
        return view('proyectosacti', compact('usuarios','proyecto'));

    }
    function apigoogle()
    {
        $usuarios = session::get('informacion');
        return view('aplicacion', compact('usuarios'));
    }
    function geocoding()
    {
        $usuarios = session::get('informacion');
        return view('geocoding', compact('usuarios'));
    }
    function cotizantes(){

        $usuarios = session::get('informacion');

        $proyectos = proyectos::with("coti")->with("tipo")->where("status","=","pendiente")->get();
        $cotizante="pendiente";
        return view('tablas_proyecto', compact('usuarios', 'proyectos', 'cotizante'));
    }
    function diagnostico(){
        $usuarios = session::get('informacion');
        $diagnostico = diagnostico::where("sp","!=", null)->get();
        return view('diagnostico', compact('usuarios', 'diagnostico'));
    }

    function entregados(){
        $usuarios = session::get('informacion');

        $proyectos = proyectos::with("coti")->with("tipo")->where("status","!=","pendiente")->get();
        $cotizante="entregado";
        return view('tablas_proyecto', compact('usuarios', 'proyectos' ,'cotizante'));
    }

}
 