<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Session;
class a extends Controller
{
    function a1(){
        return view('abc');
    }
    function vistamobil1(){
        return view('vista1mobil');
    }
    function act()
    {

        $usuarios = session::get('informacion');
        return view('aplica', compact('usuarios'));
    }
    function act2()
    {

        $usuarios = session::get('informacion');
        return view('aa', compact('usuarios'));
    } //
    function act3()
    {

        $usuarios = session::get('informacion');
        return view('activemap', compact('usuarios'));
    }
    function actestudi()
    {

        $usuarios = session::get('informacion');
        return view('proyectoact', compact('usuarios'));
    }
    function confirmarCompra(){

        return view('correos/confirmarcompra');
    }
    function eproducto1(){
        return view('correos/eproducto1');
    }
    function eproducto2(){
        return view('correos/eproducto2');
    }
    function eproducto3(){
        return view('correos/eproducto3');
    }
}
