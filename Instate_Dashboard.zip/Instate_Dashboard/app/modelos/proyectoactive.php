<?php

namespace App\modelos;

use Illuminate\Database\Eloquent\Model;

class proyectoactive extends Model
{
    protected $connection = 'mysql2';
    Protected $table='proyecto_cliente';
    public $updated_at=false;
    public $timestamps=false;
    //
}
 