<?php

namespace App\modelos;

use Illuminate\Database\Eloquent\Model;

class personas extends Model
{
    //
    Protected $primaryKey='id';
    Protected $table='personas';
    public $timestamps=false;
}
