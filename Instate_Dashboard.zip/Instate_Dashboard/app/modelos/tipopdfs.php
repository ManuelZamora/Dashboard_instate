<?php

namespace App\modelos;

use Illuminate\Database\Eloquent\Model;

class tipopdfs extends Model
{
    //
    Protected $primaryKey='id';
    Protected $table='tipos_pdfs';
    public $updated_at=false;
    public $timestamps=false;
}
