<?php

namespace App\modelos;

use Illuminate\Database\Eloquent\Model;

class permisos extends Model
{
    //
    Protected $primaryKey='id';
    Protected $table='permisos';
    public $timestamps=false;
}
