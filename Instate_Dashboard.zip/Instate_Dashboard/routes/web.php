<?php

use Facade\FlareClient\Api;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|*/

//sesiones - Vistas
Route::get('/', "usuario@inicio");
Route::get('/bienvenido', ["middleware"=>"filtrador", "uses" => "usuario@bienvenido"]);

//aplicacion de google
Route::get('/aplicacion', "routerwebController@apigoogle");
Route::get('/a', "routerwebController@geocoding");

//cotizando blade

Route::get('/cotizantes', "routerwebController@cotizantes");
Route::get('/entregados', "routerwebController@entregados");
Route::get('/actproyecto', "routerwebController@actproyecto");
Route::get('/diagnostico', 'routerwebController@diagnostico');


//sesiones peticiones
Route::post('/getsesion','usuario@logeo');
Route::get('/logout','usuario@logout');

//Consulta en django
Route::post('/busqueda', "aplicacioncontroller@busqueda");
Route::get('/calor', "aplicacioncontroller@calor");
Route::get('/colorbar', "pdfcontroller@colorbar");


//formularios de los proyectos
Route::get('/cotizando/{id}', "formularioscontroller@cotizando1");
Route::get('/proyecto/{id}', "formularioscontroller@proyecto");
Route::get('/proyect/{id}', "formularioscontroller@proyect");
Route::post('/crear', "formularioscontroller@cotizando");



//proyeccion
Route::get('/proyeccion', "formularioscontroller@proyeccion");
Route::get('/pesos', "formularioscontroller@pesos");


//pdf
Route::get('/pdfs', "pdfcontroller@pdfs");
Route::get('/pdf_proyecto', "pdfcontroller@pdf_proyecto");


//correo
Route::post('/correo', "correocontroller@correo1");
Route::get('/correos', "correocontroller@correo1s");
Route::post('/correopdf1', "correocontroller@correopdf1");
Route::post('/correopdf2', "correocontroller@correopdf2");
Route::post('/correopdf4', "correocontroller@correopdf4");






//prueba de api google
Route::get('/ss', "aplicacioncontroller@ss");

Route::get('/act', "a@act");
Route::get('/act2', "a@act2");
Route::get('/act3', "a@act3");
Route::get('/acvproc', "a@acvproc");
Route::get('/actestudi', "a@actestudi");
//prueba
Route::get('/imgs', "pdfcontroller@img");
Route::get('/imgd', "pdfcontroller@imgd");

Route::get('/abc', "a@a1");

//checar vistas en active campaing

Route::get('/vistamobil1', "a@vistamobil1");


//Correos Productos
Route::get('/confirmarc',"a@confirmarCompra");
Route::get('/producto1',"a@eproducto1");
Route::get('/producto2',"a@eproducto2");
Route::get('/producto3',"a@eproducto3");
