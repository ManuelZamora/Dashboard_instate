

<?php $__env->startSection('cssextra'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">


    <!-- Paginacion -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    </div>

    <!-- Contentenedor -->
    <div class="row justify-content-center">
        <div class="col-lg-6 align-self-center">

            <!-- carta -->
            <div class="card mb-4 r">
                <div class="card-header">
                    Bienvenido <?php echo e($usuarios['personas']->nombre); ?>

                </div>
                <div class="card-body">
                    Bueno dia "nombre de la persona" no olvides sonreir y que la vida te ilumine :D
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
    $(document).ready(function() {
        console.log(session)
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basedash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alexm\OneDrive\Escritorio\Instate\Instate_Dashboard\resources\views/inicio.blade.php ENDPATH**/ ?>