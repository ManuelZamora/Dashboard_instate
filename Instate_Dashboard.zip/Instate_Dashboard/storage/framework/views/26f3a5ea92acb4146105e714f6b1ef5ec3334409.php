<?php $__env->startSection('cssextra'); ?>
<link href="<?php echo e(asset('vendor1/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(Session::has('status')): ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<input hidden type="text" id="st" value="<?php echo e(Session::get('status')); ?>">

    <script>
        var st = $('#st').val();
        alert(st)
    </script>

<?php endif; ?>
<div class="container-fluid">
    <?php echo e(csrf_field()); ?>

    <!-- Pagina -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 id="focuss" class="h3 mb-0 text-gray-800">Proyectos cotizantes </h1>

    </div>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Tabla de clientes</h6>
        </div>
        
        <div class="card-body" id="sa">
            <div class="table-responsive">
                <?php echo e(csrf_field()); ?>

                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Cliente</th>
                            <th>Direccion</th>
                            <th>Correo</th>
                            <th>Tipo</th>
                            <?php if($cotizante=='pendiente'): ?>
                            <th>Creaccion</th>
                            <?php else: ?>
                            <th>Fecha entrega</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Cliente</th>
                            <th>Direccion</th>
                            <th>Correo</th>
                            <th>Tipo</th>
                            <?php if($cotizante=='pendiente'): ?>
                            <th>Creaccion</th>
                            <?php else: ?>
                            <th>Fecha entrega</th>
                            <?php endif; ?>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pro['coti']->nombre); ?> </td>
                            <td><?php echo e($pro->direccion); ?></td>
                            <td><?php echo e($pro['coti']->correo); ?> </td>
                            <td><?php echo e($pro['tipo']->tipo); ?></td>
                            <td>
                            <?php if($cotizante=='pendiente'): ?>
                            <a class="btn btn-success" href="/cotizando/<?php echo e($pro->id); ?>"> cotizar</a>
                            <?php else: ?>
                            <?php echo e($pro->f_entrega); ?>

                            <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>



</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor1/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor1/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<script>
    setInterval(() => {
        $('#dataTable').load(' #dataTable');
    }, 2000);
</script>

<?php echo $__env->make('template.basedash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alexm\OneDrive\Escritorio\Instate\Instate_Dashboard\resources\views/tablas_proyecto.blade.php ENDPATH**/ ?>