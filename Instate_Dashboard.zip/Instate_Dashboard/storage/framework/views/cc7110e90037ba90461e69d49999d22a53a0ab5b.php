<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Correo Producto 1</title>
</head>
<style>
    body {
        width: 1000px;
        height: 1289px;
    }

    .container {
        font-family: Arial, Helvetica, sans-serif;
        color: black;
        width: 1000px;
        height: 1289px;
        text-align: left;
        padding-left: 85px;
    }

    .datos {
        font-weight: lighter;
        padding-top: 30px;
    }

    .proyecto {
        font-weight: lighter;
    }

    .datos {
        font-weight: lighter;
    }

    .precio {
        padding-top: 20px;
        font-size: 35px;
    }

    .text-yellow {
        color: rgb(229, 197, 102);
        font-weight: lighter;
    }

    .t3 {
        margin-top: 15px;
    }
</style>

<body>
    <div class="container">
        <div class="row">
            <div class="">
                <div style="margin-top: 50px; margin-left: 20px; ">
                    <!-- <img src="https://instate.com.mx/wp-content/uploads/2022/02/producto4_landing.png" style="width:400px; "> -->
                </div>
                <div>
                    <h4 style="font-weight: lighter">Asunto:  Aquí está tu diagnóstico de inversión inmobiliaria</h4>
                    <p>
                        ¡Hola, (nombre)!

                    </p>
                    <p>
                        Adjunto a este mensaje te envío tu diagnóstico de uso de suelo y posibilidades <br>
                        de inversión inmobiliaria del terreno que me indicaste.
                    </p>
                </div>
                <div style="line-height: 150%; ">
                    <h4 class="proyecto">
                        En este documento encontrarás:
                        <p>
                        <ul>
                            <li>Las principales posibilidades de uso de suelo</li>
                            <li>Las más rentables opciones de inversión</li>
                            <li>Los cálculos aproximados de inversión y rentabilidad de acuerdo a costos<br>
                                reales y actuales de la zona.</li>
                        </ul>
                        </p>
                    </h4>
                </div>
                <div>
                    <p style="line-height: 20px; padding-left:190px;">
                        <b> [Ver mi diagnostico ahora] </b>
                    </p>
                    <p class="t3">
                        Con esto, ahora podrás decidir los siguientes pasos de tu inversión con certeza y <br>
                        claridad.
                    </p>
                </div>
                <p style="margin-top: 25px; line-height: 25px; text-align: justify;">
                    Recuerda que si hoy sabes que es momento de convertir ese terreno en una <br>
                    inversión rentable, puedo además preparar para ti un Estudio de Mercado <br>
                    Inmobiliario que te indique:
                </p>
                <p style="margin-top: 25px;  text-align: justify;">
                    <ul>
                        <li>Interpolación de precios de compra y venta en la zona</li>
                        <li>Análisis de expectativas de desarrollo en la zona</li>
                    </ul>
                </p>
                <div style="margin-top:65px; ">
                    <p style="line-height: 20px; padding-left:190px;  text-align: justify;">
                        <b> [Quiero también el Estudio de Mercado] </b>
                    </p>
                </div>
                <p>
                   Estoy feliz de saber que ahora estas mucho pas cerca de concretar tu inversión.
                </p>
                <p>
                    Seguiremos en contacto.
                    <p>
                        Instate.
                    </p>
                </p>
                <p>
                    La <b class="text-yellow">primera Inteligencia Artificial</b> que detecta, diseña y planea modelos de <br>
                    negocios inmobiliarios, con tan solo conocer la ubicación de un terreno en <br>
                    México.
                </p>
            </div>
        </div>
    </div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\alexm\Desktop\Instate_Dashboard\resources\views/correos/eproducto1.blade.php ENDPATH**/ ?>