<?php $__env->startSection('cssextra'); ?>
<link href="<?php echo e(asset('vendor1/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(Session::has('status')): ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<input hidden type="text" id="st" value="<?php echo e(Session::get('status')); ?>">

    <script>
        var st = $('#st').val();
        alert(st)
    </script>

<?php endif; ?>
<div class="container-fluid">
    <?php echo e(csrf_field()); ?>

    <!-- Pagina -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 id="focuss" class="h3 mb-0 text-gray-800">Diagnostico </h1>

    </div>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Tabla de diagnostico</h6>
        </div>
        <div class="card-body" id="sa">
            <div class="table-responsive">
                <?php echo e(csrf_field()); ?>

                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Correo</th>
                            <th>Lista</th>
                            <th>Creación</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Nombre</th>
                            <th>Correo</th>
                            <th>Lista</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $diagnostico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($diag->nombre); ?> </td>
                            <td><?php echo e($diag->correo); ?> </td>
                            <td><?php echo e($diag->lista); ?></td>
                            <td>
                            
                            <a class="btn btn-success" href="/cotizando/<?php echo e($diag->id); ?>">Cotizar</a>
                            
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>



</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor1/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor1/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.basedash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alexm\OneDrive\Escritorio\Instate\Instate_Dashboard\resources\views/diagnostico.blade.php ENDPATH**/ ?>