<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Correo Producto 1</title>
</head>
<style>
    body {
        width: 1000px;
        height: 1289px;
    }

    .container {
        font-family: Arial, Helvetica, sans-serif;
        color: black;
        width: 1000px;
        height: 1289px;
        text-align: left;
        padding-left: 85px;
    }

    .datos {
        font-weight: lighter;
        padding-top: 30px;
    }

    .proyecto {
        font-weight: lighter;
    }

    .datos {
        font-weight: lighter;
    }

    .precio {
        padding-top: 20px;
        font-size: 35px;
    }

    .text-yellow {
        color: rgb(229, 197, 102);
        font-weight: lighter;
    }

    .t3 {
        margin-top: 15px;
    }
</style>

<body>
    <div class="container">
        <div class="row">
            <div class="">
                
                <div>
                    <h4 style="font-weight: lighter">Asunto: Te envío el Modelo de Negocio para tu inversión.</h4>
                    <p>
                        ¡Hola, (nombre)!
                    </p>
                    <p>
                        La distancia entre un sueño y su realidad se mide en números.
                    </p>
                </div>
                <div style="line-height: 150%; ">
                    <h4 class="proyecto">
                        <p>
                            Te envío los números de tu proyecto
                        </p>
                        <p>
                            El Modelo de Negocio que me pediste está terminado y te comparto la <br>
                            información más relevante sobre el posible plan financiero de obra para que <br>
                            proyectes con certeza tu inversión.
                        </p>
                    </h4>
                </div>
                <div>
                    <p style="line-height: 20px; padding-left:160px; margin-top: 25px;">
                        <b> [Descargar el Modelo de Negocio] </b>
                    </p>
                    <p class="t3" style="margin-top: 30px;">
                        Te he dado los datos, ahora la decisión es tuya.
                    </p>
                </div>
                <p style="margin-top: 25px; line-height: 25px; text-align: justify;">
                    ¿Es ahora el mejor momento para convertir ese terreno en una inversión?
                </p>
                <p style="text-align: justify; line-height: 20px;">
                    Con la información que ahora tienes, podrías concretar un proyecto en tiempos <br>
                    nunca antes experimentados por la industria inmobiliaria en México. A partir de <br>
                    este momento, mis compañeros humanos expertos en ingeniería y arquitectura <br>
                    podrían trabajar para ti el Proyecto ejecutivo que contiene planos <br>
                    arquitectónicos, estructurales e instalaciones, renders y catálogo de conceptos <br>
                    en menos de 120 horas
                </p>
                <p style="text-align: justify; line-height: 20px;">
                    Recuerda que todos nuestros proyectos son supervisados y elaborados por <br>
                    grandes arquitectos y experimentados ingenieros, por lo que todos los <br>
                    proyectos cumplen con los máximos estándares nacionales e internacionales, ya <br>
                    que son elaborados a detalle como joyas Arquitectónicas Atemporales.
                </p>
                <p style="text-align: justify; line-height: 20px;">
                    Nunca antes habíamos colaborado tan de cerca en la creación y planeación de <br>
                    proyectos arquitectónicos en un equipo híbrido de profesionales respaldados por <br>
                    soluciones de Inteligencia Artificial.
                </p>
                <p style="text-align: justify; line-height: 20px;">
                    Si estás listo para ser parte de una nueva generación de inversionistas que saben que los <br>
                    datos y su oportuno análisis te dan hoy posibilidades de acelerar procesos para centrar <br>
                    el tiempo en las máximas zonas de genialidad, conversemos sobre tu proyecto.
                </p>
                <div style="margin-top:25px; ">
                    <p style="line-height: 20px; padding-left:190px; text-align: justify;">
                        <b> [Quiero agendar una llamada] </b>
                    </p>
                </div>
                <p>
                    Hagamos el mejor equipo: yo analizo los datos y tu tomas las decisiones.
                </p>
                <p>
                <p>
                    Instate.
                </p>
                La <b class="text-yellow">primera Inteligencia Artificial</b> que detecta, diseña y planea modelos
                de <br>
                negocios inmobiliarios, con tan solo conocer la ubicación de un terreno en <br>
                México.
                </p>
            </div>
        </div>
    </div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\alexm\Desktop\Instate_Dashboard\resources\views/correos/eproducto3.blade.php ENDPATH**/ ?>