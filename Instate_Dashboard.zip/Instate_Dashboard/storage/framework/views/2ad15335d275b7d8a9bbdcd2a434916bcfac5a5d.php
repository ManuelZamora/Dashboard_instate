
<?php $__env->startSection('cssextra'); ?>
<link href="<?php echo e(asset('vendor1/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form action="/correopdf1" id="form" enctype="multipart/form-data" method="POST">
    <div class="container-fluid">
        <?php echo e(csrf_field()); ?>

        <!-- Pagina -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 id="focuss" class="h3 mb-0 text-gray-800 flex-grow-1">Proyeccion</h1>
            <button id="asd" data-toggle="modal" type="submit" data-target="#datos_busqueda" class="d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                Enviar al correo</button>
            <input type="text" name="id_proy" hidden value="<?php echo e($id); ?>">
        </div>
        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Proyeccion</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="inputTipoSuelo">Tipo de suelo</label>
                        <select id="inputTipoSuelo" name="inputTipoSuelo" class="form-control">
                            <?php $__currentLoopData = $tipos_suelo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_suelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tipo_suelo); ?>"><?php echo e($tipo_suelo); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="row mt-2">
                            <div class="form-group col-md-6">
                                <label for="inputDensidad">Densidad</label>
                                <input type="text" placeholder="Media Alta" class="form-control" name="inputDensidad" id="inputDensidad">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputPAM">Porcentaje de área multifamiliar</label>
                                <input type="text" placeholder="NO APLICA" class="form-control" name="inputPAM" id="inputPAM">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="form-group col-md-6">
                                <label for="inputLMF">Lote minimo multifamiliar</label>
                                <input type="text" placeholder="NO APLICA" class="form-control" name="inputLMF" id="inputLMF">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputCDE">Cajones de estacionamiento</label>
                                <input type="text" placeholder="1 CAJÓN POR VIVIENDA MAS 15% DEL TOTAL PARA VISITAS" name="inputCDE" class="form-control" id="inputCDE">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="form-group col-md-6">
                                <label for="inputUsosViables">Usos viables</label>
                                <?php $__currentLoopData = $usos_viables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uso_viable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <br>
                                <input type="checkbox" name="$inputUsosViables[]" value="<?php echo e($uso_viable); ?>" class="mr-2"><strong><?php echo e($uso_viable); ?></strong><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputUsosCondicionados">Usos condicionados</label>
                                <?php $__currentLoopData = $usos_condicionados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uso_condicionado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <br>
                                <input type="checkbox" name="$inputUsosCondicionados[]" value="<?php echo e($uso_condicionado); ?>" class="mr-2"><strong><?php echo e($uso_condicionado); ?></strong> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="observacionesTextarea">Observaciones</label>
                        <textarea class="form-control" name="observacionesTextarea" style="resize:none;" id="observacionesTextarea" rows="18" placeholder="Agregue sus observaciones..."></textarea>
                    </div>
                </div>
            </div>
        </div>
     </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor1/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor1/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
<script>
    function validarFormulario(evento) {
        var mensaje = confirm("¿Los datos ingresados son correctos?");
        console.log(mensaje)
        if (mensaje) {

        } else {

        }
    }
    document.addEventListener("DOMContentLoaded", function() {
        document.getElementById("form").addEventListener('submit', validarFormulario);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.basedash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alexm\OneDrive\Escritorio\Instate\Instate_Dashboard\resources\views/proyeccion.blade.php ENDPATH**/ ?>