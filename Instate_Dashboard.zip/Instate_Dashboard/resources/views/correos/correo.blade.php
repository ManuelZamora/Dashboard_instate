<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<h5>Estimado(a)  {{$cliente}}</h5>

<h5>Por medio de la presente le enviamos la cotización solicitada.
Gracias por darnos la oportunidad de participar y ayudarle a que este proyecto sea un éxito.
Quedamos en espera de sus comentarios y le agradecemos la confirmación de recepción de este presupuesto.
Saludos y gracias por su preferencia,</h5>
<h5>Notas</h5>


</body>
</html>