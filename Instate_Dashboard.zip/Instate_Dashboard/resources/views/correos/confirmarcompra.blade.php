<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Confirmar Compra</title>
</head>
<style>
    body {
        width: 1000px;
        height: 1289px;
    }

    .container {
        font-family: Arial, Helvetica, sans-serif;
        color: black;
        width: 1000px;
        height: 1289px;
        text-align: left;
        padding-left: 85px;
    }

    .datos {
        font-weight: lighter;
        padding-top: 30px;
    }

    .proyecto {
        font-weight: lighter;
    }

    .datos {
        font-weight: lighter;
    }

    .precio {
        padding-top: 20px;
        font-size: 35px;
    }
    .text-yellow{
        color: rgb(229, 197, 102);
        font-weight: lighter;
    }
    .t3{
        margin-top: 15px;
    }
</style>

<body>
    <div class="container">
        <div class="row">
            <div class="">
                <div style="margin-top: 50px; margin-left: 20px; ">
                    <!-- <img src="https://instate.com.mx/wp-content/uploads/2022/02/producto4_landing.png" style="width:400px; "> -->
                </div>
                <div>
                    <h4 style="font-weight: lighter">Asunto: Te confirmo que recibi tu pedido</h4>
                    <p>
                        ¡Hola, (nombre)!

                    </p>
                    <p>
                        Te confirmo que recibí tu pedido de (Nombre de producto) con el que te <br> enviaremos:
                    </p>
                </div>
                <div style="line-height: 200%; ">
                    <h4 class="proyecto">
                        Listado de Entregables
                    </h4>
                </div>
                <div>
                    <p style="line-height: 20px;">
                        Ya estoy trabajando en la preparación de los datos, mapas y cálculos que <br>
                        recibirás en unas horas desde esta misma dirección.
                    </p>
                    <p class="t3">
                        Recuerda que mi base de datos y algoritmos ya conocemos las posibilidades de <br>
                        uso de sueño y potenciales opciones de inversión en el terreno que me indicaste,<br>
                        pero mis compañeros humanos se están asegurando de que la ubicación y <br>
                        cálculos sean correctos para enviarte información validada por ellos.
                    </p>
                </div>
                <p>
                    Por favor no respondas aún a este correo a menos que no vuelvas a saber de mi <br>
                    en las próximas 24 horas.
                </p>
                <p>
                    Mientras tanto, puedes ir imaginando el futuro de esa inversión
                </p>
                <div>
                    <p>
                        Hasta pronto, <br>
                    <p>
                        Instate.
                    </p>
                    </p>
                </div>
                <p>
                    La <b class="text-yellow">primera Inteligencia Artificial</b> que detecta, diseña y planea modelos de <br>
                    negocios inmobiliarios, con tan solo conocer la ubicación de un terreno en <br>
                    México.
                </p>
            </div>
        </div>
    </div>
    </div>
</body>

</html>
