<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Correo Producto 1</title>
</head>
<style>
    body {
        width: 1000px;
        height: 1289px;
    }

    .container {
        font-family: Arial, Helvetica, sans-serif;
        color: black;
        width: 1000px;
        height: 1289px;
        text-align: left;
        padding-left: 85px;
    }

    .datos {
        font-weight: lighter;
        padding-top: 30px;
    }

    .proyecto {
        font-weight: lighter;
    }

    .datos {
        font-weight: lighter;
    }

    .precio {
        padding-top: 20px;
        font-size: 35px;
    }

    .text-yellow {
        color: rgb(229, 197, 102);
        font-weight: lighter;
    }

    .t3 {
        margin-top: 15px;
    }
</style>

<body>
    <div class="container">
        <div class="row">
            <div class="">
                {{-- <div style="margin-top: 50px; margin-left: 20px; ">
                    <!-- <img src="https://instate.com.mx/wp-content/uploads/2022/02/producto4_landing.png" style="width:400px; "> -->
                </div> --}}
                <div>
                    <h4 style="font-weight: lighter">Asunto: Aquí va tu Estudio de Mercado Inmobiliario</h4>
                    <p>
                        ¡Hola, (nombre)!
                    </p>
                    <p>
                        ¡Enhorabuena por dar pasos tan certeros en tu inversión inmobiliaria!
                    </p>
                </div>
                <div style="line-height: 150%; ">
                    <h4 class="proyecto">
                        <p>
                            Te envío el Estudio de Mercado que me pediste para conocer los precios y <br>
                            proyecciones de crecimiento en la zona donde se ubica tu terreno.
                        </p>
                        <p>
                            El documento que te envío está hecho a partir de mi base de datos con <br>
                            propiedades actuales a precios y tasas de compra - venta de estos momentos, <br>
                            por lo que puedes confiar en esta información para conocer el potencial actual <br>
                            de tu inversión.
                        </p>
                    </h4>
                </div>
                <div>
                    <p style="line-height: 20px; padding-left:160px; margin-top: 45px;">
                        <b> [Ver mi Estudio de Mercado ahora] </b>
                    </p>
                    <p class="t3">
                        Con esta información estás a un paso de generar todo un plan de inversión y a <br>
                        partir de los cientos de proyectos que guardo en mi base de datos, podría darte, <br>
                        en las próximas 72 horas, el plan financiero de tu obra y sus precios probables de <br>
                        venta para que tengas en los próximos días el Modelo de Negocio que requieres.
                    </p>
                </div>
                <p style="margin-top: 25px; line-height: 25px; text-align: justify;">
                    Si quieres recibir ahora el Modelo de Negocio o conocer más de la información <br>
                    que te puedo ofrecer, te muestro algunos ejemplos:
                </p>
                <div style="margin-top:25px; ">
                    <p style="line-height: 20px; padding-left:130px; text-align: justify;">
                        <b> [Quiero ver cómo es el Modelo de Negocio] </b>
                    </p>
                </div>
                <p>
                    Me emociona saber que te acercas cada vez más a tu nueva inversión.
                </p>
                <p style="margin-top: 25px;">
                    Seguiremos en contacto.
                </p>
                <p>
                    <p>
                        Instate.
                    </p>
                    La <b class="text-yellow">primera Inteligencia Artificial</b> que detecta, diseña y planea modelos
                    de <br>
                    negocios inmobiliarios, con tan solo conocer la ubicación de un terreno en <br>
                    México.
                </p>
            </div>
        </div>
    </div>
    </div>
</body>

</html>
